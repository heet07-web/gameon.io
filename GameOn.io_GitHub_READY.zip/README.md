# GameOn.io — GitHub Pages Ready

This is the complete frontend package for GameOn.io.

## Upload to GitHub

After extracting this ZIP, upload the **contents of this folder** to the root of your GitHub repository.

The repository root should contain:

- index.html
- product.html
- aboutus.html
- contactus1.html
- buynow.html
- css/style.css
- js/script.js
- assets/*

Do not place these files inside another `GameOn_V3` folder.

## GitHub Pages

Repository → Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

## Local preview

Open `index.html` in a browser, or use VS Code + Live Server.

## Note

The cart, wishlist, filters and form validation are frontend JavaScript features. Checkout and contact submission are demos until a real backend/payment service is connected.
